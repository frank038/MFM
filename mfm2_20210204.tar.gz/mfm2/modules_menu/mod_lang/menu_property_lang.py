MPR_PAGE1 = "Size"
MPR_SEL_ITEMS = "Selected Items"
MPR_IT_SIZE = "Size"
